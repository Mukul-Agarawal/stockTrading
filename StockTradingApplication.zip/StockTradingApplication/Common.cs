﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockTradingApplication
{
    public class Common
    {
        public int id;
        public string name;
        public string passwd;
    }
}
