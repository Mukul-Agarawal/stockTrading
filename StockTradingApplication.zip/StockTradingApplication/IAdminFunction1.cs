﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockTradingApplication
{
    interface IAdminFunction1
    {
        void RegisterStock();
        void ViewStock();
    }
}
