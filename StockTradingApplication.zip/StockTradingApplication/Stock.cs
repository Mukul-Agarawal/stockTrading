﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockTradingApplication
{
    public class Stock
    {
        public string stock_Name;
        public string company_Name;
        public double buy_Price;
        public double sell_Price;
        public int quantity;
        public double TradingFeePercentage;
    }
}
